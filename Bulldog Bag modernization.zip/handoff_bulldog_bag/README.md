# Handoff: Bulldog Bag Ltd.

## Overview
Three separate marketing-site redesigns, one HTML file each. All three are modernizations of live sites: each keeps the real business's content, contact details, service list and brand colors, restructured into a 2026 single-page layout with scroll reveals, hover states and working section navigation.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, **not production code to copy directly**.

The task is to **recreate these designs in the target codebase's existing environment** (Next.js, Astro, WordPress theme, Webflow, etc.) using its established patterns, component structure and CSS approach. If no environment exists yet, pick the framework that fits the project — these are content-driven marketing sites, so a static-site generator (Astro/Next static export) or a CMS theme is the natural fit, with the copy moved into a CMS/content layer rather than hardcoded.

Implementation notes that matter when porting:
- Every style in these files is an **inline style** for prototype-streaming reasons. Do not carry that over — convert to the codebase's CSS solution (CSS modules, Tailwind, SCSS). The token tables below give you the values.
- All interaction is driven by a small imperative script attached to `data-*` attributes (`data-reveal`, `data-card`, `data-svc`, `data-row`, `data-scope`, `data-q`, `data-chip`). In a component framework, re-express these as component state + CSS transitions, not DOM querying.
- The hero headline reveal is a **CSS keyframe** (`line-rise`) whose resting state is visible — keep that property (never gate content visibility on JS).
- `support.js` is the prototype runtime that renders these files in a browser. It is **not** part of the design and should not be ported.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, copy and interaction behavior. Recreate pixel-accurately using the codebase's libraries. Type scales use `clamp()` and layouts use `repeat(auto-fit, minmax(...))` — the designs are fully fluid from ~360px to ~1600px with no fixed breakpoints except the nav collapse.

---

# 1. Bulldog Bag Ltd.

Industrial-editorial. Black chrome, off-white paper sections, lime accent.

## Design tokens
| Token | Value | Use |
|---|---|---|
| Ink | `#080807` | Header, footer, dark sections. **Must stay exact** — the logo PNG has a matching black field and blends into it. |
| Paper | `#F2F2F0` | Light sections |
| Lime accent | `#A5D759` | CTAs, ticker band, rules, active states (CSS var `--accent`) |
| Body ink | `#2b2b26` / `#57574f` | Paragraphs, secondary text |
| Muted label | `#6E6E68` | Mono labels |
| Hairline | `rgba(8,8,7,.14)` light / `rgba(242,242,240,.14)` dark | Grid dividers |
| Display / body font | Hanken Grotesk 400–800 | Matches the live site's geometric grotesque |
| Mono font | IBM Plex Mono 400/500 | Micro-labels, stats, meta |
| Page gutter | `clamp(20px, 4vw, 44px)` | |
| Container | `max-width: 1440px` | |
| Section padding | `clamp(72px, 10vw, 150px)` vertical | |
| Radius | `999px` on pills/buttons; everything else square | |
| Motion | `.8s cubic-bezier(.2,.7,.2,1)` reveals; `1s cubic-bezier(.16,.84,.26,1)` headline lines | |

## Sections (in order)
1. **Header** (fixed, two rows). Top utility strip 34px: "Family-owned since 1965" + phone `604 273 8021`. Main bar 82px → **62px on scroll past 40px**, logo 38px → 28px. Nav: About Us, Services, Products, Markets, Resources, Contact — each with a lime underline that grows to 100% on hover and opens a **full-width mega panel** (`max-height 0 → 420px`, .45s) with a description column plus a link grid. Lime "Request a Quote" pill at right, lifts 2px on hover. Below 1080px: nav + pill hide, a bordered burger appears right-aligned and opens a full-screen black panel with 40px display-type links.
2. **Hero** (min-height `min(92vh, 1000px)`, black). Their real plant video (`https://www.bulldogbag.com/wp-content/uploads/2024/09/bulldog_banner.mp4`) autoplay/muted/loop, poster = press-floor still, plus a dual gradient scrim (105° left-dark, plus bottom-up black). Lime dot + mono eyebrow, then `clamp(46px, 9.4vw, 146px)/0.86` headline in three masked lines — "Packaging / Beyond / **Expectation**" (third line lime) — each rising from 108% with 0.05/0.16/0.27s delays. Sub-paragraph max 44ch, two CTAs. Bottom border strip: four stat cells (1965 · 10-colour · 21 · 6) that **count up** when scrolled into view.
3. **Ticker** — lime band, two duplicated rows of industry names scrolling `-50%` over 44s.
4. **Positioning** — two-column: headline "Elevating packaging, empowering brands." + three bordered pills; right column body copy with lime-underlined `or` emphasis.
5. **Products** — three full-bleed panels (`minmax(300px,1fr)`, 1px hairline gaps, min-height `clamp(380px,42vw,520px)`). Each: photo with a bottom-up scrim, white title, 34ch description, mono spec line, lime-underlined text link. Photo scales `1.04 → 1.11` over 1.1s on hover.
6. **Services** — black. Four rows, each `title + description + hairline`. On hover the row indents 18px and the title turns lime.
7. **Process** — four cells with an oversized quiet numeral (`rgba(8,8,7,.22)`), title, copy.
8. **Trust ("Packaging with Purpose")** — family portrait with a lime "Since 1965" plate overlapping its bottom-left corner; right column body copy + three bordered credential cells.
9. **Industries** — 21 pills; hover fills lime and lifts 2px.
10. **Insights** — two article cards (image zoom `1.03 → 1.08` on hover) + a bordered glossary card.
11. **Quote CTA** — full lime section, headline `clamp(34px,5vw,74px)/0.96`, with a black form card: name/company/email, five toggleable scope chips (fill lime + black text when selected), submit button whose label swaps to a thank-you for 3.2s.
12. **Footer** — logo, nav columns, five locations with a lime "HQ" tag on Langley, newsletter field, legal row.

## Content facts (verified against the live site — do not invent more)
Founded 1965, family-owned; up to ten-colour flexographic printing; 21 industries listed; HQ 5838 274th Street, Langley BC V4W 0B8; phone 604-273-8021; locations Langley BC, Alberta prairies, California, Oregon, Washington.

---

## Shared interaction spec
- **Scroll reveals** — elements below 92% of the viewport start at `opacity 0 / translateY(24px)` and animate to rest on intersection (`rootMargin 0 0 -12% 0`, threshold .08), each element once. Respect `prefers-reduced-motion: reduce` (all three sites already do).
- **Counters** — integers ease out over ~1s on first intersection at 60% visibility. Bulldog's "1965" counts from 1905 so it reads as a year, not a tally.
- **Headline masks** — a fixed-height `overflow: hidden` wrapper per line, inner span animated `translateY(108%) → 0`. The wrapper carries `padding-bottom: .14em; margin-bottom: -.14em` so descenders (g, y, p) are not clipped.
- **Nav collapse** — pure CSS media query, so navigation works before/without JS. Keep that guarantee.
- **Forms** — all three are non-submitting prototypes with optimistic label swaps. Wire to the real endpoint (Bulldog's is a WordPress quote form; OVG uses Resova/Birrdi for bookings but needs an events enquiry endpoint; Red Mechanical has no form today).

## Assets (`assets/`)
All photography is **AI-generated placeholder imagery supplied by the client for layout purposes** — replace with real photography before launch. File names describe contents.

- `logo-bulldog.png` — **extracted from a screenshot of the live site**; get the original vector/PNG from the client. OVG has no logo file, so its wordmark is currently typeset in Anton.
- Bulldog: `bdb-press-floor`, `bdb-plastic-bags`, `bdb-paper-bags`, `bdb-rollstock`, `bdb-family`, `bdb-grocery-shelf`, `bdb-compliance`.
- OVG: `ovg-cocktails`, `ovg-patio`, `ovg-group`. The hero, both booking cards and the wide bar shot **hotlink the client's own Wix CDN** (`static.wixstatic.com/media/4ad306_…`) — download and self-host these on build.
- Red Mechanical: `rm-mechroom-hero`, `rm-mechroom-custom`, `rm-townhouse-framing`, `rm-commercial-water-entry`, `rm-boilerroom-360`, `rm-manifold-detail`, `rm-dwv-roughin`, `rm-backflow-assembly`, `rm-parkade-services`, `rm-finished-ensuite`.
- Bulldog's hero video hotlinks `bulldogbag.com/wp-content/uploads/2024/09/bulldog_banner.mp4` — self-host it (and compress: add a WebM source and a poster).

## Files in this bundle
```
Bulldog Bag.dc.html      design reference — Bulldog Bag
OVG Putt Lounge.dc.html  design reference — OVG Putt Lounge
Red Mechanical.dc.html   design reference — Red Mechanical
support.js               prototype runtime (needed only to open the HTML files; do not port)
assets/                  images referenced by the three files
```

## Before launch (open items)
1. Sample Red Mechanical's exact brand red from their logo.
2. Source real logo files for Bulldog Bag and OVG.
3. Replace all placeholder photography; self-host the OVG Wix images and the Bulldog video.
4. Confirm OVG's opening hours (currently "posted weekly on Instagram") and whether Red Mechanical's virtual tours are still live.
5. Add real form endpoints, plus SEO/meta, favicons, analytics and accessibility passes (visible focus states are not specified in these prototypes).
